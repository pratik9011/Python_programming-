# Online Food Delivery developed by using Django

## Requirements
- Python 3.* version

## Project Setup Process

### For Windows
```javascript
    - git clone https://github.com/ChanduArepalli/Django-Online-Food-Delivery.git
    - cd Django-Online-Food-Delivery
    - pip install -r requirements.txt
    - python manage.py runserver
```

### For Ubuntu/ Linux
```javascript
    - git clone https://github.com/ChanduArepalli/Django-Online-Food-Delivery.git
    - cd Django-Online-Food-Delivery
    - pip3 install -r requirements.txt
    - python3 manage.py runserver
```